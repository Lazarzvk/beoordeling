<?php
//fetch.php
require "config.inc.php";
$output = '';
if(isset($_POST["query"]))
{
 $search = mysqli_real_escape_string($mysqli, $_POST["query"]);
 $query = "
  SELECT * FROM beoordeling_project, beoordeling_toegevoegdProject
  WHERE name LIKE '%".$search."%'
  OR type LIKE '%".$search."%' 
  OR start_time LIKE '%".$search."%'
  OR end_time LIKE '%".$search."%'
  OR grade LIKE '%".$search."%'
 ";
}
else
{
 if ( $_SESSION['level'] == 1 )
      {
        $query = mysqli_query($mysqli, "SELECT * FROM beoordeling_toegevoegdProject WHERE client=".$_SESSION['user_id']);
        
        // Als er minstens 1 row(dagje uit) is waar de user aan mee doet
                if(mysqli_num_rows($query) >= 1)
                {
                  // Zet de gegevens in een array
                    while($row = mysqli_fetch_array($query))
                    {
                      // Query om de gegevens van het dagje uit te krijgen
            $query1 = mysqli_query($mysqli,"SELECT * FROM beoordeling_project WHERE project_id=".$row['project_id']);
            
            // Zet de gegevens in een array
            while($row1 = mysqli_fetch_array($query1))
            {
              
            
                    $output .= "
          div class='insideContaintLeft'>
          <div class='insideContaintLeftTitle'>
          <h2>Naam project: " . $row2['name'] . "</h2>
          </div>
          <div class='insideContaintLeftContent'>
          <p>Type: " . $row2['type'] . "</p>
          <p>Begin datum: " . $row1['start_time'] . "</p>
          <p>Eind datum: " . $row1['end_time'] . "</p>
          <a style='text-decoration: none;' href='projectInformation.php?ID_toegevoegdProject=".$row1['ID_toegevoegdProject']."'>Meer informatie...</a>
          </div>
          </div>
      ";
      }
 echo $output;
}
else
{
 echo 'Niks gevonden';
}
                                    
            }
                    }
                }
                else
                {
                    echo "<p>Er is geen project op dit moment, klik <a href='https://81746.ict-lab.nl/beoordeling/addProject.php'>hier</a> om een project toe  te voegen.</p>";
                }
      }
      else
      {
        
                $query = mysqli_query($mysqli, "SELECT * FROM beoordeling_userProjecten WHERE user_id=".$_SESSION['user_id']);
        
  
                if(mysqli_num_rows($query) >= 1)
                {

                    while($row = mysqli_fetch_array($query))
                    {

            $query1 = mysqli_query($mysqli,"SELECT * FROM beoordeling_toegevoegdProject WHERE ID_toegevoegdProject=".$row['ID_toegevoegdProject']);
            

            while($row1 = mysqli_fetch_array($query1))
            {
              $query2 = mysqli_query($mysqli,"SELECT * FROM beoordeling_project WHERE project_id=".$row1['project_id']);
            

            while($row2 = mysqli_fetch_array($query2))
            {
              
            
              echo "<div class='insideContaintLeft'>";
                          echo "<div class='insideContaintLeftTitle'>";
                          echo "<h2>Naam project: " . $row2['name'] . "</h2>";
              echo "</div>";
              echo "<div class='insideContaintLeftContent'>";
              echo "<p>Type: " . $row2['type'] . "</p>";
              echo "<p>Begin datum: " . $row1['start_time'] . "</p>";
              echo "<p>Eind datum: " . $row1['end_time'] . "</p>";
              echo "<a style='text-decoration: none;' href='projectInformation.php?ID_toegevoegdProject=".$row1['ID_toegevoegdProject']."'>Meer informatie...</a>";
              echo "</div>";
              echo "</div>";
            }
            }
                    }
                }
                else
                {
                    echo "<p>Je doet op dit moment niet mee aan een project.</p>";
                }
      }
}



?>