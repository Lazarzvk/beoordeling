<?php

require "session.php";
$ID_toegevoegdProject = $_GET['ID_toegevoegdProject'];

session_regenerate_id();
if(isset($_POST['submit']) && isset($_POST['cijfer']))
{
	$cijfer = $_POST['cijfer'];

	$query =  "UPDATE beoordeling_toegevoegdProject SET grade = '$cijfer' WHERE ID_toegevoegdProject = '$ID_toegevoegdProject'";
	if ( mysqli_query( $mysqli, $query ) )
			{
		echo "<script>alert('Cijfer is succesvol aangepast!');</script>";

	}
}
$title = "home";

require "header.php";

?>
<link href="css/home.css" rel="stylesheet">
		<?php

		if ( $_SESSION[ 'level' ] == 1 ) {

			?>
<div class="zoekmachine">
	<div class="insideZoekmachine">
		<div class="leftZoekmachnie">
		 	<h4>Project informatie</h4>
		</div>
</div>
</div>

<?php
		}
			?>
<div class="containt">
	<div class="insideContaint">
		

			<?php
		
			// Als de user het level 1 heeft
		
				  $query = mysqli_query($mysqli, "SELECT * FROM beoordeling_toegevoegdProject WHERE ID_toegevoegdProject=".$ID_toegevoegdProject);
				
				// Als er minstens 1 row(dagje uit) is waar de user aan mee doet
                if(mysqli_num_rows($query) >= 1)
                {
                	// Zet de gegevens in een array
                    while($row = mysqli_fetch_array($query))
                    {
                    	// Query om de gegevens van het dagje uit te krijgen
						$query1 = mysqli_query($mysqli,"SELECT * FROM beoordeling_project WHERE project_id=".$row['project_id']);
						
						// Zet de gegevens in een array
						while($row1 = mysqli_fetch_array($query1))
						{
							$query2 = mysqli_query($mysqli,"SELECT * FROM beoordeling_userProjecten WHERE ID_toegevoegdProject=".$ID_toegevoegdProject);
							
							echo "<div class='insideContaintLeft'>";
	                        echo "<div class='insideContaintLeftTitle'>";
	                        echo "<h2>Naam project: " . $row1[ 'name' ] . "</h2>";
	                        echo "</div>";
	                        echo "<div class='insideContaintLeftContent'>";
	                        echo "<p>Type: " . $row1[ 'type' ] . "</p>";
	                        echo "<p>Begin datum: " . $row[ 'start_time' ] . "</p>";
	                        echo "<p>Eind datum: " . $row[ 'end_time' ] . "</p>";
								if ( $_SESSION[ 'level' ] == 0 ) {
									if(empty($row['grade'])){
										echo "<p>Cijfer: Project is actief</p>";
									}
									else{
									echo "<p>Cijfer: ".$row['grade']."</p>";
								}
								}
									if ( $_SESSION[ 'level' ] == 1 ) {
										echo"<form method='post' action=''>";
										echo"<label>Cijfer: </label>";
										echo"<input class='cijfer' type='number' name='cijfer' value='".$row['grade']."'>";
										echo"<input type='submit' name='submit' value='Cijfer invoeren'>";
										echo"</form>";
									}
	                        echo "</div>";
	                        echo "</div>";
	                        echo "<div class='insideContaintRight'>";
	                        echo "<div class='insideContaintRightTitle'>";
	                        echo "<h2>Deelnemers:</h2>";
	                        echo "</div>";
	                        echo "<div class='insideContaintRightContent'>";
	                        while ( $row2 = mysqli_fetch_array( $query2 ) ) {

	                        	$query3 = mysqli_query( $mysqli, "SELECT * FROM beoordeling_user WHERE user_id=" . $row2[ 'user_id' ] );
	                        	while ( $row3 = mysqli_fetch_array( $query3 ) ) {
	                        		echo "<p>" . $row3[ 'firstName' ] . " " . $row3[ 'lastName' ] . "</p>";
	                        	}
							}
	                        	echo "</div>";
	                        	echo "</div>";
	                       
	                        }
	                        }
	                        } else {
	                        	echo "<p>Er is geen project op dit moment</p>";
	                        }
		
            ?>

		
	</div>
	</div>
	
<?php
	
require "footer.php";

?>