<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>
		<?php echo $title; ?>
	</title>
	<link rel="stylesheet" href="css/style.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>

<body>
	<nav class="navbar">
		<img src="images/logo.png" class="logo">
		<a href="home.php">Beoordelingssysteem</a>

		<?php

		if ( $_SESSION[ 'level' ] == 1 ) {

			?>
		<a href="addProject.php">Aanmaken</a>
		<a href="addUser.php">Voeg user toe</a>

		<?php

		}
		?>
		<div class="dropdown">
			<button class="dropbtn">
				<?php echo $_SESSION['firstName'] . " " . $_SESSION['lastName']; ?>
				<i class="fa fa-caret-down"></i>
			</button>
			<div class="dropdown-content">
				<a href="account.php">Mijn account</a>
				<a href="loguit.php">Afmelden</a>

			</div>
		</div>



	</nav>