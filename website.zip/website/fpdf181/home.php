<?php

require "session.php";

session_regenerate_id();

$title = "home";

require "header.php";

?>
<link href="css/home.css" rel="stylesheet">
		<?php

		if ( $_SESSION[ 'level' ] == 1 ) {

			?>
<div class="zoekmachine">
	<div class="insideZoekmachine">
		<div class="leftZoekmachnie">
		 	<h4>Projecten</h4>
		</div>
	<div class="input">
      <input type="text" placeholder="Search.." name="search">
    
 
	</div>
</div>

<?php
		}
			?>
<div class="containt">
	<div class="insideContaint">
		

			<?php
			// Als de user het level 1 heeft
			if ( $_SESSION['level'] == 1 )
			{
				$query = mysqli_query($mysqli, "SELECT * FROM beoordeling_toegevoegdProject WHERE client=".$_SESSION['user_id']);
				
				// Als er minstens 1 row(dagje uit) is waar de user aan mee doet
                if(mysqli_num_rows($query) >= 1)
                {
                	// Zet de gegevens in een array
                    while($row = mysqli_fetch_array($query))
                    {
                    	// Query om de gegevens van het dagje uit te krijgen
						$query1 = mysqli_query($mysqli,"SELECT * FROM beoordeling_project WHERE project_id=".$row['project_id']);
						
						// Zet de gegevens in een array
						while($row1 = mysqli_fetch_array($query1))
						{
							
						
							echo "<div class='insideContaintLeft'>";
	                        echo "<div class='insideContaintLeftTitle'>";
	                        echo "<h2>Naam project: " . $row1['name'] . "</h2>";
							echo "</div>";
							echo "<div class='insideContaintLeftContent'>";
							echo "<p>Type: " . $row1['type'] . "</p>";
							echo "<p>Begin datum: " . $row['start_time'] . "</p>";
							echo "<p>Eind datum: " . $row['end_time'] . "</p>";
							echo "<a style='text-decoration: none;' href='projectInformation.php?ID_toegevoegdProject=".$row['ID_toegevoegdProject']."'>Meer informatie...</a>";
							echo "</div>";
							echo "</div>";
							                      
						}
                    }
                }
                else
                {
                    echo "<p>Er is geen project op dit moment</p>";
                }
			}
			else
			{
				// Lees de images uit de database tabel
                $query = mysqli_query($mysqli, "SELECT * FROM beoordeling_userProjecten WHERE user_id=".$_SESSION['user_id']);
				
				// Als er minstens 1 row(dagje uit) is waar de user aan mee doet
                if(mysqli_num_rows($query) >= 1)
                {
                	// Zet de gegevens in een array
                    while($row = mysqli_fetch_array($query))
                    {
                    	// Query om de gegevens van het dagje uit te krijgen
						$query1 = mysqli_query($mysqli,"SELECT * FROM beoordeling_project WHERE project_id=".$row['project_id']);
						
						// Zet de gegevens in een array
						while($row1 = mysqli_fetch_array($query1))
						{
							
						
							echo "<div class='insideContaintLeft'>";
	                        echo "<div class='insideContaintLeftTitle'>";
	                        echo "<h2>Naam project: " . $row1['name'] . "</h2>";
							echo "</div>";
							echo "<div class='insideContaintLeftContent'>";
							echo "<p>Type: " . $row1['type'] . "</p>";
							echo "<p>Begin datum: " . $row['start_time'] . "</p>";
							echo "<p>Eind datum: " . $row['end_time'] . "</p>";
							echo "<a style='text-decoration: none;' href='projectInformation.php?ID_toegevoegdProject=".$row['ID_toegevoegdProject']."'>Meer informatie...</a>";
							echo "</div>";
							echo "</div>";
							                      
						}
                    }
                }
                else
                {
                    echo "<p>Er is geen project op dit moment</p>";
                }
			}
            ?>

		
	</div>
	</div>
	
<?php

//require "footer.php";

?>