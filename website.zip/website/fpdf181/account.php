<?php

require "session.php";

session_regenerate_id();

$title = "Account";

require "header.php";

?>

<h1>Jouw accountgegevens</h1>

<?php

if($_SESSION['level'] > 0)
{	
	echo "<p>Voornaam: " . $_SESSION['firstName'] . "</p>";
	echo "<p>Achternaam: " . $_SESSION['lastName'] . "</p>";
	echo "<p>Gebruikersnaam: " . $_SESSION['username'] . "</p>";

	$getStudentQuery = mysqli_query($mysqli, "SELECT * FROM `beoordeling_user` WHERE level = 0");

	if(mysqli_num_rows($getStudentQuery) >= 1)
	{
		echo "<hr><h2>De projecten van de leerlingen:</h2>";
		$gradesQuery = mysqli_query($mysqli, "SELECT * FROM beoordeling_userProjecten");

		if(mysqli_num_rows($gradesQuery) >= 1)
		{
			while($studentRow = mysqli_fetch_array($getStudentQuery) && $gradeRow = mysqli_fetch_array($gradesQuery))
			{
				echo "<p><b>Gebruiker:</b> " . $gradeRow['user_id'] ."</p>";

				if(empty($gradeRow['grade']))
				{
					echo "<p><b>Cijfer:</b> Nog bezig met project</p>";
				}
				else
				{
					echo "<p><b>Cijfer:</b> " . $gradeRow['grade'] . "</p>";
				}
				elseif($gradeRow['activeProject'] == 0)
				{
					echo "<p><b>Gebruiker:</b> " . $noGradeRow['user_id'] . "</p>";
				}
			}
		}
		else
		{
			echo "<p>Er zijn nog geen afgemaakte projecten.</p>";
		}
	}
	else
	{
		echo "U moet nog leerlingen toevoegen, klik <a href='addUser.php'>hier</a> om dat te doen";
	}
}
else
{
	echo "Welkom terug leerling!";
}

?>

<?php

require "footer.php";

?>