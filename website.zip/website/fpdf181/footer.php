    <footer>
        <label>&copy; Copyright | Beoordelingssysteem</label>
    </footer>
</body>
</html>