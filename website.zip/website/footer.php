    <footer>
        <label>&copy; Copyright | Beoordelingssysteem</label>
    </footer>
<script src="js/ajax.js"></script>    
</body>
</html>