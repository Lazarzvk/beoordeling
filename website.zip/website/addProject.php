<?php

require "session.php";

session_regenerate_id();

$title = "voeg project toe";

require "header.php";

if($_SESSION['level'] == 0)
{
    header("Location: home.php");
}
else
{

$selectedProject = strip_tags($mysqli, $_POST['selectedProject']);
$start_time = strip_tags($mysqli, $_POST['start_time']);
$end_time = strip_tags($mysqli, $_POST['end_time']);
$selectedTeacher = strip_tags($mysqli, $_POST['selectedTeacher']);

$selectedProject = mysqli_real_escape_string($mysqli, $_POST['selectedProject']);	
$start_time = mysqli_real_escape_string($mysqli, $_POST['start_time']);	
$end_time = mysqli_real_escape_string($mysqli, $_POST['end_time']);	
$selectedTeacher = mysqli_real_escape_string($mysqli, $_POST['selectedTeacher']);	

// Verwerking van het project toevoegen
if(isset($_POST['submit']) && isset($_POST['selectedProject']) && isset($_POST['start_time']) && isset($_POST['end_time']) && isset($_POST['selectedTeacher']))
{
	if(!empty($_POST['selectedProject']) && !empty($_POST['start_time']) && !empty($_POST['end_time']) && !empty($_POST['selectedTeacher']) && !empty($_POST['student']))
	{
		// Converteer de start datum
		$startTime = new DateTime($start_time);
		$startTime = date_format($startTime, "Y-m-d");

		// Converteer de eind datum
		$endTime = new DateTime($end_time);
		$endTime = date_format($endTime, "Y-m-d");

		// Eindatum op dezelfde dag als startdatum?
		if($endTime == $startTime)
		{
			// Geef een "error"
			echo "<p>De einddatum mag niet op dezelfde dag zijn als de startdatum</p>";
		}
		// Einddatum voor startdatum
		elseif($endTime < $startTime)
		{
			// Geef een "error"
			echo "<p>De einddatum mag niet eerder dan de startdatum zijn</p>";
		}
		// Eindatum na startdatum
		elseif($endTime > $startTime)
		{
			// Als er meer dan 1 student is aangevinkt
			if(count($_POST['student']) >= 1)
			{
				if($setToegevoegdProjectQuery = mysqli_query($mysqli, "INSERT INTO `beoordeling_toegevoegdProject` (`start_time`, `end_time`, `client`, `grade`, `project_id`) VALUES ('$startTime', '$endTime', '$selectedTeacher', NULL,'$selectedProject');")){
				$ID_toegevoegdProject = mysqli_insert_id($mysqli);
				foreach($_POST['student'] as $s)
				{
					
						
					
					
					
					
					$setProjectQuery = mysqli_query($mysqli, "INSERT INTO `beoordeling_userProjecten` (`user_id`, `ID_toegevoegdProject`) VALUES ('$s','$ID_toegevoegdProject');");
					$setActiveProjectQuery = mysqli_query($mysqli, "UPDATE `beoordeling_user` SET `activeProject` = '$selectedProject' WHERE `beoordeling_user`.`user_id` = $s;");

					// Check of de queries zijn gelukt
					if($setProjectQuery == 1 && $setActiveProjectQuery == 1 && $setToegevoegdProjectQuery == 1)
					{	
						
	    						
	    					
						
						// Zet tekst in variabele zodat deze maar 1 keer op het scherm komt
						$message = "Het project is aangemaakt! <p>Student: " . $s . "<br> Leraar: " . $selectedTeacher . "</p>";
						continue;
					}
				}
				}
				// Als er een message variabele is
				if(isset($message))
				{
					echo $message;
				}
			}
		
		}
	}
	else
	{
		echo "<p>Vul alle velden in en kies tenminste 1 leerling!</p>";
	}
}

// Einde van het project toevoegen

?>
<link href="css/home.css" rel="stylesheet">
<div class="zoekmachine">
	<div class="insideZoekmachine">
		<div class="leftZoekmachnie">
		 	<h4>Project aanmaken</h4>
		</div>
</div>
</div>
<div class="containt">
	<div class="insideContaint">
		<div class="insideContaintLeft">
			<div class="insideContaintLeftTitle">
<h2>Project toevoegen</h2>
			</div>
			<div class="insideContaintLeftContent">
<form method="POST">
    <p>Project:
	    	<?php
	    	$getProjectsQuery = mysqli_query($mysqli, "SELECT * FROM beoordeling_project");

	    	if(mysqli_num_rows($getProjectsQuery) >= 1)
	    	{
	    		echo "<select name='selectedProject'>";

	    		while($projectRow = mysqli_fetch_array($getProjectsQuery))
	    		{
	    			echo "<option value='" . $projectRow['project_id'] . "'>" . $projectRow['name'] . "(" . $projectRow['type'] . ") </option>";
	    		}

	    		echo "</select>";
	    	}
	    	else
	    	{
	    		echo "Er ging iets fout, probeer het opnieuw";
	    	}

	    	?>
	</p>
    <p>Start datum: <input type="date" name="start_time"></p>
    <p>Eind datum: <input type="date" name="end_time"></p>
    <p>Begeleider:
		<?php
	    	$getclientQuery = mysqli_query($mysqli, "SELECT * FROM beoordeling_user WHERE level = 1");

	    	if(mysqli_num_rows($getclientQuery) >= 1)
	    	{
	    		echo "<select name='selectedTeacher'>";

	    		while($clientRow = mysqli_fetch_array($getclientQuery))
	    		{
	    			echo "<option value='" . $clientRow['user_id'] . "'>" . $clientRow['lastName'] . "</option>";
	    		}

	    		echo "</select>";
	    	}
	    	else
	    	{
	    		echo "Er ging iets fout, probeer het opnieuw";
	    	}

	    	?>
    </p>
    <p>Studenten:</p>
    <?php
    $getUserQuery = mysqli_query($mysqli, "SELECT * FROM beoordeling_user WHERE level = 0");

    if(mysqli_num_rows($getUserQuery) >= 1)
    {
    	while($userRow = mysqli_fetch_array($getUserQuery))
    	{
    		if($userRow['activeProject'] >= 1)
    		{
    			echo "<p><input type='checkbox' disabled>" . $userRow['username'] . "</p>";
    		}
    		else
    		{
    			echo "<label><input type='checkbox' name='student[]' value='" . $userRow['user_id'] . "'>" . $userRow['username'] . "</label><br>";
    		}
    	}
    }

    ?>
    <input type="submit" name="submit">
</form>
			</div>
		</div>
	</div> 
</div>
<?php

require "footer.php";
}
?>