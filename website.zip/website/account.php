<?php

require "session.php";

session_regenerate_id();

$title = "Account";

require "header.php";

?>

<link href="css/home.css" rel="stylesheet">
	
<div class="zoekmachine">
	<div class="insideZoekmachine">
		<div class="leftZoekmachnie">
		 	<h4>Uw account</h4>
		</div>
</div>
</div>


<div class="containt">
	<div class="insideContaint">
		<div class="insideContaintLeft">
				<div class="insideContaintLeftTitle">
					<h2>Account</h2>
			</div>
	<div class="insideContaintLeftContent">

<?php

if($_SESSION['level'] > 0)
{	
	echo "<p>Voornaam: " . $_SESSION['firstName'] . "</p>";
	echo "<p>Achternaam: " . $_SESSION['lastName'] . "</p>";
	echo "<p>Gebruikersnaam: " . $_SESSION['username'] . "</p>";
}
else
{
	echo "<p>Voornaam: " . $_SESSION['firstName'] . "</p>";
	echo "<p>Achternaam: " . $_SESSION['lastName'] . "</p>";
	echo "<p>Gebruikersnaam: " . $_SESSION['username'] . "</p>";
}

?>
			</div>
		</div>
				<div class="insideContaintLeft">
				<div class="insideContaintLeftTitle">
<h2>Wachtwoord wijzigen</h2>
					</div>
						<div class="insideContaintLeftContent">

<?php

/*
* Verwerk van wachtwoord wijzigen
*/

if(isset($_POST['submit']) && isset($_POST['password']) && isset($_POST['cnf_password']))
{
	if(empty($_POST['password']) || empty($_POST['cnf_password']))
	{
		echo "<p>Vul alle velden in!</p>";
	}
	else
	{
		$password = sha1($_POST['password']);
		$cnf_password = sha1($_POST['cnf_password']);

		if($password == $cnf_password)
		{
			$changePassword = mysqli_query($mysqli, "UPDATE `beoordeling_user` SET `password` = '$password' WHERE `beoordeling_user`.`user_id` = '" . $_SESSION['user_id'] . "';");

			if($changePassword >= 1)
			{
				echo "<script>alert('Uw wachtwoord is succesvol gewijzigd.');</script>";
			}
			else
			{
				echo "<p>Er ging iets fout, probeer het opnieuw.</p>";
			}
		}
		else
		{
			echo "<p>De wachtwoorden komen niet overeen.</p>";
		}
	}
}

?>
<form method="POST">
	<p>Wachtwoord: <input type="password" name="password"></p>
	<p>Bevestig wachtwoord: <input type="password" name="cnf_password"></p>
	<input type="submit" name="submit">
</form>
					</div>
		</div>
	</div>
</div>
<?php

require "footer.php";

?>