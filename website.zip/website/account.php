<?php

require "session.php";

session_regenerate_id();

$title = "Account";

require "header.php";

?>

<h1>Jouw accountgegevens</h1>

<?php

if($_SESSION['level'] > 0)
{	
	echo "<p>Voornaam: " . $_SESSION['firstName'] . "</p>";
	echo "<p>Achternaam: " . $_SESSION['lastName'] . "</p>";
	echo "<p>Gebruikersnaam: " . $_SESSION['username'] . "</p>";

	$getStudentQuery = mysqli_query($mysqli, "SELECT * FROM `beoordeling_user` WHERE level = 0");

	if(mysqli_num_rows($getStudentQuery) >= 1)
	{
		echo "<hr><h2>De actieve projecten van de leerlingen:</h2>";
		$userProjectQuery = mysqli_query($mysqli, "SELECT * FROM beoordeling_userProjecten");

		if(mysqli_num_rows($userProjectQuery) >= 1)
		{
			$getGradeQuery = mysqli_query($mysqli, "SELECT * FROM beoordeling_toegevoegdProject");

			while($studentRow = mysqli_fetch_array($getStudentQuery) && $userProjectRow = mysqli_fetch_array($userProjectQuery) && $getGradeRow = mysqli_fetch_array($getGradeQuery))
			{
				echo "<p><b>Gebruiker:</b> " . $userProjectRow['user_id'] ."</p>";

				if(empty($getGradeRow['grade']))
				{
					echo "<p><b>Cijfer:</b> Nog bezig met project</p>";

					$getProjectNameQUery = mysqli_query($mysqli, "SELECT * FROM `beoordeling_project` WHERE `project_id` IN (SELECT `beoordeling_toegevoegdProject`.`project_id` FROM `beoordeling_userProjecten`, `beoordeling_toegevoegdProject` WHERE `beoordeling_userProjecten`.`ID_toegevoegdProject` = " . $userProjectRow['ID_toegevoegdProject'] .  ")");

					if(mysqli_num_rows($getProjectNameQUery) >= 1)
					{
						while($getProjectNameRow = mysqli_fetch_array($getProjectNameQUery))
						{
							echo "<p><b>Project: " . $getProjectNameRow['name'] ."</b></p>";
						}
					}
					else
					{
						echo "<p><b>Project:</b> Er ging iets fout, probeer het later opnieuw</p>";
					}
				}
				else
				{
					echo "<p><b>Cijfer:</b> " . $getGradeRow['grade'] . "</p>";
					echo "<p><b>Project: " . $userProjectRow['userProjecten_id'] ."</b></p>";
				}
			}

			$noProjectQuery = mysqli_query($mysqli, "SELECT * FROM `beoordeling_user` WHERE level = 0");

			if(mysqli_num_rows($noProjectQuery))
			{
				echo "<h2>Studenten die geen actief project hebben:</h2>";
				while($noProjectRow = mysqli_fetch_array($noProjectQuery))
				{
					echo "<p><b>Gebruikersnaam: </b>" . $noProjectRow['username'] . "</p>";
				}
			}
			else
			{
				echo "<p>Alle studenten doen mee aan een project.</p>";
			}
		}
		else
		{
			echo "<p>Er zijn op dit moment geen actieve projecten, klik <a href='https://81746.ict-lab.nl/beoordeling/addProject.php'>hier</a> om een project toe  te voegen.</p>";
		}
	}
	else
	{
		echo "U moet nog leerlingen toevoegen, klik <a href='addUser.php'>hier</a> om dat te doen";
	}
}
else
{
	echo "Welkom terug leerling!";
}

?>

<?php

require "footer.php";

?>