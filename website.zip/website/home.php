<?php

require "session.php";

session_regenerate_id();

$title = "home";

require "header.php";

?>
<link href="css/home.css" rel="stylesheet">
		
<div class="zoekmachine">
	<div class="insideZoekmachine">
		<div class="leftZoekmachnie">
		 	<h4>Projecten</h4>
		</div>
	<div class="input">
      <input type="text" placeholder="Search.." name="search_text" id="search_text">
    
 
	</div>
</div>


<div class="containt">
	<div class="insideContaint">

		<div id="result">
			
		</div>
		

			<?php
			// Als de user het level 1 heeft
			if ( $_SESSION['level'] == 1 )
			{
				$query = mysqli_query($mysqli, "SELECT * FROM beoordeling_toegevoegdProject WHERE client=".$_SESSION['user_id']);
				
				// Als er minstens 1 row(dagje uit) is waar de user aan mee doet
                if(mysqli_num_rows($query) >= 1)
                {
                	// Zet de gegevens in een array
                    while($row = mysqli_fetch_array($query))
                    {
                    	// Query om de gegevens van het dagje uit te krijgen
						$query1 = mysqli_query($mysqli,"SELECT * FROM beoordeling_project WHERE project_id=".$row['project_id']);
						
						// Zet de gegevens in een array
						while($row1 = mysqli_fetch_array($query1))
						{
							?>
						
							<div id="result">
								
							<?php                      
						}
                    }
                }
                else
                {
                    echo "<p>Er is geen project op dit moment, klik <a href='https://81746.ict-lab.nl/beoordeling/addProject.php'>hier</a> om een project toe  te voegen.</p>";
                }
			}
			else
			{
				
                $query = mysqli_query($mysqli, "SELECT * FROM beoordeling_userProjecten WHERE user_id=".$_SESSION['user_id']);
				
	
                if(mysqli_num_rows($query) >= 1)
                {

                    while($row = mysqli_fetch_array($query))
                    {

						$query1 = mysqli_query($mysqli,"SELECT * FROM beoordeling_toegevoegdProject WHERE ID_toegevoegdProject=".$row['ID_toegevoegdProject']);
						

						while($row1 = mysqli_fetch_array($query1))
						{
							$query2 = mysqli_query($mysqli,"SELECT * FROM beoordeling_project WHERE project_id=".$row1['project_id']);
						

						while($row2 = mysqli_fetch_array($query2))
						{
							
						
							?>
						
							<div id="result">
								
							<?php 
						}
						}
                    }
                }
                else
                {
                    echo "<p>Je doet op dit moment niet mee aan een project.</p>";
                }
			}
            ?>

		
	</div>
	</div>
	
<?php

require "footer.php";

?>